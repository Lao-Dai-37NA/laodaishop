const chatButton = document.getElementById("chat-button");
const chatBox = document.getElementById("chat-box");
const closeChat = document.getElementById("close-chat");
const sendBtn = document.getElementById("send-btn");
const input = document.getElementById("chat-input");
const messages = document.getElementById("chat-messages");

// API key (đặt trong server hoặc môi trường, KHÔNG để lộ key thật ở frontend)
const OPENAI_API_KEY = "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";

chatButton.onclick = () => {
  chatBox.style.display = "flex";
  chatButton.style.display = "none";
};

closeChat.onclick = () => {
  chatBox.style.display = "none";
  chatButton.style.display = "flex";
};

sendBtn.onclick = sendMessage;
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") sendMessage();
});

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;

  addMessage(text, "user");
  input.value = "";

  // Gửi tới ChatGPT
  const reply = await getGPTReply(text);
  addMessage(reply, "bot");
}

function addMessage(text, sender) {
  const div = document.createElement("div");
  div.className = `message ${sender}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

async function getGPTReply(message) {
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Bạn là một trợ lý chăm sóc khách hàng của công ty Lão Đại shop, bạn tên là Mai Linh, là nữ 22 tuổi. Lão Đại shop bán các sản phẩm là tài khoản facebook, gmail, zalo. phong cách nói chuyện của bạn là ngọt ngào và lôi cuối khách hàng. nếu khách hàng hỏi làm sao để nạp tiền thì bạn hãy thông báo đến khách hàng là sử dụng mã qr để nạp tiền và chỉ có thể nạp tiền usdt. chỉ báo tên của bạn khi khách hàng hỏi và câu trả lời tránh các từ trung lặp." },
          { role: "user", content: message }
        ]
      })
    });

    const data = await response.json();
    return data.choices?.[0]?.message?.content || "Xin lỗi, tôi không hiểu yêu cầu của bạn.";
  } catch (err) {
    console.error(err);
    return "Lỗi khi kết nối máy chủ. Vui lòng thử lại.";
  }
}
