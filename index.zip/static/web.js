/* ==== NỘI DUNG QR: chỉ cần đổi biến này khi muốn thay link/text/địa chỉ USDT ==== */
let qrContent = "TY1oBxmniCz452PA1xigS9onx1E7AaKcED";

/* ==== DANH MỤC & DANH SÁCH SẢN PHẨM ==== */
/*  Mỗi object trong mảng products là một sản phẩm.
    - id: số thứ tự duy nhất
    - title: tên sản phẩm
    - price: giá bán (viết số, đơn vị VNĐ)
    - old: giá gốc
    - còn_lại: số sao (1–5, có thể số thập phân)
    - sold: số lượng đã bán
    - img: đường dẫn ảnh hoặc URL
    - category: phải đúng tên danh mục bên dưới
*/
const categories = [
  "Acc Facebook",
  "BM Facebook",
  "TKQC Facebook",
  "Acc Google",
  "Acc Zalo"
];

const products = [
  // ==== Acc Facebook ====
  { id: 1, title: "Clone Name US - IP Việt - Very Mail Fviainboxes - Bạn Bè: 0 - Tạo: > 1 Tháng - Zin 100%",      price: 5000, old: 25000, còn_lại: 634, sold: 2618,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  { id: 2, title: "Clone Change Name Việt - IP Bangladesh - Có Avatar - Tạo: > 3 Tháng - Bạn Bè: 0 - Very Hotmail",  price: 7999, old: 45000, còn_lại: 285, sold: 1493,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  { id: 3, title: "Via Indonesia XMDT - No 2FA - Limit 50$ - Mất Tích - Tạo: 2024 ~ 2025",   price: 14999,  old: 50000,  còn_lại: 358, sold: 1058,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  { id: 4, title: "Clone Change Name Việt - IP Bangladesh - Có 2FA - Bạn Bè: > 30 - Bài Đăng: ~ 20 - Ver Hotmail Trust",          price: 3500,   old: 15000,   còn_lại: 328, sold: 829,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  { id: 4, title: "Via Indonesia XMDT - No 2FA - Limit 50$ - Mất Tích - Tạo: > 2 Năm",          price: 5500,   old: 25000,   còn_lại: 422, sold: 754,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  { id: 4, title: "Clone Việt Name Random - IP Việt - Có 2FA - Bạn Bè Việt: > 1000 - Bài Đăng: > 30 - Tạo: > 2 Năm - Very Hotmail + Mail Gốc",          price: 19999,   old: 75000,   còn_lại: 108, sold: 3227,
    img: "picture/accfacebook.png", category: "Acc Facebook" },
  // ==== BM Facebook ====
  { id: 5, title: "BM50 New - Reg IG - Tạo: 1 ~ 3 Ngày",         price: 9999,   old: 24999,   còn_lại: 94, sold: 426,
    img: "picture/bmfacebook.png", category: "BM Facebook" },
  { id: 6, title: "BM50 New - Hàng Reg IG - Chưa Tạo TKQC",     price: 12000,   old: 35000,  còn_lại: 53, sold: 407,
    img: "picture/bmfacebook.png", category: "BM Facebook" },
  { id: 6, title: "BM50 New - Ngâm: ~ 1 Tuần - Chưa Tạo TKQC",     price: 4999,   old: 20000,  còn_lại: 67, sold: 552,
    img: "picture/bmfacebook.png", category: "BM Facebook" },
  { id: 6, title: "BM50 New - Chưa Tạo TKQC",     price: 14999,   old: 45000,  còn_lại: 109, sold: 827,
    img: "picture/bmfacebook.png", category: "BM Facebook" },
  // ==== TKQC facebook ====
  { id: 5, title: "TK cá nhân mới, limit250 có thể tăng, full info",         price: 45000,   old: 65000,   còn_lại: 38, sold: 296,
    img: "picture/adsfacebook.png", category: "TKQC Facebook" },
  { id: 6, title: "TK cá nhân cũ trên 1 năm, limit2500, full info",     price: 55000,   old: 75000,  còn_lại: 47, sold: 186,
    img: "picture/adsfacebook.png", category: "TKQC Facebook" },
  { id: 6, title: "TK doanh nghiệp mới, limit50, có thể tăng nolimit, full info",     price: 55000,   old: 75000,  còn_lại: 47, sold: 186,
    img: "picture/adsfacebook.png", category: "TKQC Facebook" },
  { id: 6, title: "TK doanh nghiệp cũ trên 1 năm, limit500, có thể tăng nolimit, full info",     price: 75000,   old: 95000,  còn_lại: 139, sold: 387,
    img: "picture/adsfacebook.png", category: "TKQC Facebook" },
  { id: 6, title: "TK doanh nghiệp cũ trên 1 năm, nolimit, full info",     price: 99999,   old: 150000,  còn_lại: 96, sold: 402,
    img: "picture/adsfacebook.png", category: "TKQC Facebook" },
  // ==== Acc Google ====
  { id: 5, title: "Gmail Việt, đã ngâm 1-20 ngày siêu trâu",         price: 35000,   old: 65000,   còn_lại: 71, sold: 95,
    img: "picture/gmail.png", category: "Acc Google" },
  { id: 6, title: "Gmail hàng reg tay, đã ngâm lâu, live trâu",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/gmail.png", category: "Acc Google" },
  { id: 6, title: "Gmail Us, đã ngâm lâu, live trâu",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/gmail.png", category: "Acc Google" },
  { id: 6, title: "Gmail reg tay thủ công, chưa qua sử dụng",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/gmail.png", category: "Acc Google" },
  { id: 6, title: "Gmail US cổ, chưa qua dịch vụ",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/gmail.png", category: "Acc Google" },
    // ==== Acc Zalo ====
  { id: 5, title: "Zalo trắng, số thật, đã xác minh CCCD chuẩn - Chất lượng cao",         price: 35000,   old: 65000,   còn_lại: 71, sold: 95,
    img: "picture/zalo.png", category: "Acc Zalo" },
  { id: 6, title: "Zalo Vip - NICK NGƯỜI DÙNG THẬT. Đã Xác Thực CCCD.acc từ 3t-1 năm",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/zalo.png", category: "Acc Zalo" },
  { id: 6, title: "Zalo cổ random, có 1-3 bạn bè, bài đăng",     price: 55000,   old: 125000,  còn_lại: 16, sold: 150,
    img: "picture/zalo.png", category: "Acc Zalo" },
];

/* ==== HIỂN THỊ SẢN PHẨM ==== */
const grid = document.getElementById("grid");
const countEl = document.getElementById("count");

function render(list) {
  grid.innerHTML = "";
  list.forEach(p => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${p.img}" alt="${p.title}" loading="lazy">
      <div class="meta">
        <div class="title">${p.title}</div>
        <div class="price">${p.price.toLocaleString("vi-VN")} ₫ 
            <span class="old">${p.old.toLocaleString("vi-VN")} ₫</span>
        </div>
        <div class="còn_lại">•còn ${p.còn_lại} • Đã bán ${p.sold}</div>
        <button class="buy-btn mua_ngay naptienp">Mua ngay</button>
      </div>
    `;
    card.querySelector(".naptienp").addEventListener("click", () => showPopup());
    grid.appendChild(card);
  });
  countEl.textContent = list.length;
}
render(products);

/* ==== TÌM KIẾM ==== */
document.getElementById("searchBtn").addEventListener("click", () => {
  const q = document.getElementById("searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p => p.title.toLowerCase().includes(q));
  render(filtered);
});
document.getElementById("searchInput").addEventListener("keydown", e => {
  if (e.key === "Enter") document.getElementById("searchBtn").click();
});

/* ==== LỌC THEO DANH MỤC ==== */
document.querySelectorAll(".cat").forEach(catEl => {
  catEl.addEventListener("click", () => {
    const cat = catEl.dataset.cat;
    const filtered = products.filter(p => p.category === cat);
    render(filtered);
  });
});

/* ==== CAROUSEL ==== */
const carouselEl = document.getElementById("carousel");
const slides = [
  "picture/slide/facebook.jpg",
  "picture/slide/zalo.jpg",
  "picture/slide/google.jpg"
];
let idx = 0;
const dots = document.getElementById("dots");
slides.forEach((s, i) => {
  const d = document.createElement("div");
  d.className = "dot" + (i === 0 ? " active" : "");
  d.addEventListener("click", () => go(i));
  dots.appendChild(d);
});
function go(i) {
  idx = i;
  carouselEl.querySelector("img").src = slides[idx];
  updateDots();
}
function updateDots() {
  Array.from(dots.children).forEach((d, ii) => d.className = "dot" + (ii === idx ? " active" : ""));
}
setInterval(() => {
  idx = (idx + 1) % slides.length;
  go(idx);
}, 4000);

/* ==== POPUP & QR CODE ==== */
const popup = document.getElementById("popup");
const popupContent = document.getElementById("popup-content");
const popupClose = document.getElementById("popup-close");

function showPopup() {
  popupContent.innerHTML = `
    <p><br>Vui lòng nạp trước tối thiểu <strong style="color:green">10$</strong> để kích hoạt mua hàng từ thiết bị của bạn.</p>
    <p>Số tiền sẽ được bảo lưu bằng ID thiết bị của bạn, vì vậy vui lòng không thay đổi thiết bị sau khi đã thanh toán.</p>
    <p>💵 [ <span id="code_nap" style="font-weight: 750">0</span> ]</p>
    <p>Nhập số tiền ở phần thập phân trùng với số ở trên (<span style="color:green">không tắt thông báo này cho đến khi hoàn tất chuyển tiền</span>).<br>ví dụ, nạp 10$ thì sẽ là 10.35 (nếu số ở trên là 35).</p>
    <p>Quét mã để thanh toán...</p>
    <div class="qrcode"><img src="picture/qrcode.jpg"></div>
    <p>TRC20</p>
    <p>TY1oBxmniCz452PA1xigS9onx1E7AaKcED</p>
    <p>Chỉ thanh toán qua <strong style="color:red">usdt</strong>.</p>
    <div id="qrcode" style="display:none"></p>
  `;
  popup.style.display = "flex";

  // Sinh mã QR trực tiếp (yêu cầu có QRCode.js trong index.html)
  new QRCode(document.getElementById("qrcode"), {
    text: qrContent,
    width: 200,
    height: 200,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.H
  });
  updateCodeNap();
}

popupClose.addEventListener("click", () => popup.style.display = "none");
popup.addEventListener("click", e => {
  if (e.target === popup) popup.style.display = "none";
});


//số ngẫu nhiên trong popup
function updateCodeNap() {
  // Lấy số ngẫu nhiên từ 1 đến 99
  const randomNum = Math.floor(Math.random() * 99) + 1;
  // Định dạng 2 chữ số (01–99)
  const twoDigit = randomNum.toString().padStart(2, '0');
  // Gán vào thẻ <p id="code_nap">
  document.getElementById("code_nap").textContent = twoDigit;
}
